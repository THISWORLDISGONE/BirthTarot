# 塔羅生命靈數計算器 (Tarot Birth Cards Calculator)

🔮 **極端詳細的塔羅生命藍圖分析工具**

## 🌟 在線體驗
**立即使用：** https://cum-road-ster.github.io/TarotBirthCard/

## ✨ 核心功能

### 🎯 Mary K. Greer 計算系統
- 精確的生命靈數計算
- 陰影牌 (Shadow Card) 分析  
- 太陽特殊三重奏 (19/10/1) 支持
- 三種牌組類型：統一型、標準雙牌組、特殊三重奏

### 📊 雙重檢視模式
- **簡要概覽**：快速了解基本牌卡信息
- **極端詳細分析**：多維度深度報告系統

### 🎭 多維度卡牌分析
每張牌包含：
- 🎯 核心原型解釋
- ✨ 天賦與潛能分析  
- ⚠️ 挑戰與陰影面
- 🌱 個人成長路徑
- 🎲 在牌組中的特定角色

### 🌌 牌組互動分析
- 靈魂牌與個性牌的能量動力學
- 陰影牌的整合指引
- 特殊組合的創造循環解讀

## 🚀 使用方法

### 在線使用
直接訪問：https://cum-road-ster.github.io/TarotBirthCard/

### 本地使用
1. 下載 `index.html` 文件
2. 用瀏覽器打開即可使用

### 開發者集成
```bash
git clone https://github.com/CUM-ROAD-sTER/TarotBirthCard.git
```

## 📁 文件結構
- `index.html` - 完整的獨立網頁應用
- `PAC` - React 組件版本
- `Detailed` - 完整的卡牌資料庫

## 🔬 技術特色
- 純前端實現，無需服務器
- 響應式設計，支持所有設備
- 動態報告生成系統
- 交互式手風琴UI
- 個性化分析引擎

## 🎨 設計亮點
- 漸層紫粉色主題
- 可展開的多層次信息架構
- 直覺的雙模式切換
- 優雅的動畫效果

---

**基於 Mary K. Greer 的塔羅生命靈數系統**  
**Made with ❤️ for spiritual seekers**
